
<?php $__env->startSection('title','Riwayat Transaksi'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">    
</head>
<body>
    <?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="/profile/main" class="btn btn-outline-danger">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-backspace-fill" viewBox="0 0 16 16">
            <path d="M15.683 3a2 2 0 0 0-2-2h-7.08a2 2 0 0 0-1.519.698L.241 7.35a1 1 0 0 0 0 1.302l4.843 5.65A2 2 0 0 0 6.603 15h7.08a2 2 0 0 0 2-2V3zM5.829 5.854a.5.5 0 1 1 .707-.708l2.147 2.147 2.146-2.147a.5.5 0 1 1 .707.708L9.39 8l2.146 2.146a.5.5 0 0 1-.707.708L8.683 8.707l-2.147 2.147a.5.5 0 0 1-.707-.708L7.976 8 5.829 5.854z"/>
            </svg>
        </a>
        <h1>Riwayat Transaksi</h1>
        <?php $__currentLoopData = $TransactionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="riwayat">
            <div class="id">Transaction ID: <?php echo e($td->TransactionID); ?></div>
            <div class="date">Transaction Date: <?php echo e($td->TransactionDate); ?></div>
            <div class="periode">Rent Periode :
                <span class="mulai">Mulai Sewa : <?php echo e($td->MulaiSewa); ?></span><br>
                <span class="selesai">Selesai Sewa : <?php echo e($td->SelesaiSewa); ?></span>
            </div>
            <div class="item">
                <p style="color:white;">ID Pakaian : <?php echo e($td->PakaianID); ?></p>
                <p style="color:white;">Nama Pakaian : <?php echo e($td->PakaianNama); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sewabajupedia\resources\views/profile\history.blade.php ENDPATH**/ ?>