
<?php $__env->startSection('title','Home'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/agen.css')); ?>">
</head>
<body>
    <!-- navbar -->
    <?php $__env->startSection('navbar'); ?>
    <nav>
        <div class="navigation-bar">
            <div class="item-left">
                <div class="home-nav">
                    <a href="" style="color:green;">Home</a>
                </div>

                <?php if($role == "Customer"): ?> 
                <div class="kategori-nav">
                    <a href="/dashboard/customer/category">Kategori</a>
                </div>
                <?php endif; ?>

                <div class="about-nav">
                    <a class="about-nav" href="">About</a>
                </div>
                <div class="FAQ-nav">
                    <a class="FAQ-nav" href="">FAQ</a>
                </div>
            </div>

            <div class="item-right">
                <!-- profile picture -->
                <a href="/profile/main">
                    <div class="profile">
                    <?php if($role == "Customer"): ?> 
                        <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $c->CustomerPicturePath)); ?>" alt="profile">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif($role == "Agent"): ?>
                        <?php $__currentLoopData = $AgentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/' . $a->AgentPicturePath)); ?>" alt="profile">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>
                </a>

                <!-- change role -->
                <?php if($role == "Customer"): ?> 
                <select name="role" id="role" onchange="location = this.value;" autofocus>
                    <option value="" selected>Customer</option>
                    <option value="/set_agent">Agent</option>
                </select>
                <?php elseif($role == "Agent"): ?>
                <select name="role" id="role" onchange="location = this.value;" autofocus>
                    <option value="/set_customer">Customer</option>
                    <option value="" selected>Agent</option>
                </select>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <!-- customer -->
    <?php if($role == "Customer"): ?> 
    <div class="content">
    </div>

    <!-- alert message -->
    <?php if(Session::get('fail')): ?>
        <script>
            swal("Sorry", "<?php echo e(Session::get('fail')); ?>", "error");
        </script>
    <?php elseif(Session::get('success')): ?>
        <script>
            swal("Transaction Success", "<?php echo e(Session::get('success')); ?>", "success");
        </script>
    <?php endif; ?>
    
    <!-- agent -->
    <?php elseif($role == "Agent"): ?>
    <div class="content2">
        <div class="list-clothes">
            <div class="header-list">
                <p>List Pakaian</p>
                <a href="/dashboard/agent/add" class="btn btn-info">Add Product</a>
            </div>

            <div class="list-per-clothes">
                <!-- looping here -->
                <?php $__currentLoopData = $PakaianData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="clothes-card">
                    <img src="<?php echo e(asset('storage/' . $pd->PakaianGambar)); ?>" alt="" height="50px" width="50px">
                    <div class =card2>
                        <div class="card-text">
                            <p><?php echo e($pd->PakaianNama); ?></p>
                            <p class="price">Rp. <?php echo e($pd->PakaianHarga); ?>/hari</p>
                            <div class="stars">
                                &#9733; <?php echo e($pd->PakaianRating); ?> of 5
                            </div>
                        </div>
                        <div class ="edit-delete">
                            <a href="/dashboard/agent/edit/<?php echo e($pd->PakaianID); ?>"class="btn btn-success">Edit</a>
                            <a href="/dashboard/agent/delete/<?php echo e($pd->PakaianID); ?>/execution" class="btn btn-danger">Hapus</a>
                        </div>
                    </div> 
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php if(Session::get('success')): ?>
        <script>
            swal("Success", "<?php echo e(Session::get('success')); ?>", "success");
        </script>
    <?php endif; ?>

    <?php endif; ?>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sewabajupedia\resources\views/dashboard.blade.php ENDPATH**/ ?>