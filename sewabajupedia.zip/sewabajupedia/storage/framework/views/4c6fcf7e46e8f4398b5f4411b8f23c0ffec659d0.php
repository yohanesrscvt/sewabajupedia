
<?php $__env->startSection('title','Kategori'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/kategori_formal.css')); ?>">
</head>
<body>
    <!-- navbar -->
    <?php $__env->startSection('navbar'); ?>
    <nav>
        <div class="navigation-bar">
            <div class="item-left">
                <div class="home-nav">
                    <a href="/dashboard/customer">Home</a>
                </div>

                <div class="kategori-nav">
                    <a href="/dashboard/customer/category">Kategori</a>
                </div>

                <div class="about-nav">
                    <a class="about-nav" href="">About</a>
                </div>
                <div class="FAQ-nav">
                    <a class="FAQ-nav" href="">FAQ</a>
                </div>
            </div>

            <div class="item-right">
                <!-- profile picture -->
                <a href="/profile/main">
                    <div class="profile">
                        <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $c->CustomerPicturePath)); ?>" alt="profile">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </a>

                <!-- change role -->
                <select name="role" id="role" onchange="location = this.value;" autofocus>
                    <option value="" selected>Customer</option>
                    <option value="/set_agent">Agent</option>
                </select>
            </div>
        </div>
    </nav>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div></div>
        <div class="kategori-type">
            <div class="kategori-title">
                <h1><?php echo e($Kategori->KategoriNama); ?></h1>
            </div>
        </div>

        <div class="kategori-choose">
            <p></p>
        </div>

        <div class="list-cloth">
            <?php $__currentLoopData = $PakaianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/dashboard/customer/category/pakaian/<?php echo e($pl->PakaianID); ?>" class="cloth-card" style="text-decoration:none;">
                <img src="<?php echo e(asset('storage/' . $pl->PakaianGambar)); ?>" alt="">
                <div class="card-text">
                    <p><?php echo e($pl->PakaianNama); ?></p>
                    <p class="price">Rp. <?php echo e($pl->PakaianHarga); ?>/hari</p>
                    <div class="stars">
                        &#9733;<?php echo e($pl->PakaianRating); ?> of 5
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sewabajupedia\resources\views/customer-role\pakaian.blade.php ENDPATH**/ ?>