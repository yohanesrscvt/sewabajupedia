<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h1>This is Agent Dashboard</h1><br>
    
    <?php $__currentLoopData = $AgentData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src='<?php echo e($a->AgentPicturePath); ?>' alt="User Profile Image"><br>
        <p>Saldo: <?php echo e($a->AgentSaldo); ?></p><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- change role -->
    <select name="role" id="role" onchange="location = this.value;" autofocus>
        <option value="">Agent</option>
        <option value="/set_customer">Customer</option>
    </select><br>
    <!-- end change role -->

    <a href="">My Account</a><br>
    <a href="/logout">Logout</a>

    <hr>
    <br>
    <br>

    <!-- product view -->
    <?php $__currentLoopData = $PakaianData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <img src="<?php echo e(asset('storage/' . $pd->PakaianGambar)); ?>" alt="" height="50px" width="50px">
        <p><?php echo e($pd->PakaianNama); ?></p><br>
        <p>Rp. <?php echo e($pd->PakaianHarga); ?>/hari</p><br>
        <p>Rating <?php echo e($pd->PakaianRating); ?> of 5</p>
        <a href="/dashboard/agent/edit/<?php echo e($pd->PakaianID); ?>">Edit</a>
        <a href="/dashboard/agent/delete/<?php echo e($pd->PakaianID); ?>/execution">Hapus</a>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end product view -->

</body>
</html><?php /**PATH D:\sewabajupedia\resources\views/agent-role\dashboard.blade.php ENDPATH**/ ?>