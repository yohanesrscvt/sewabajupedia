
<?php $__env->startSection('title','Detail Pakaian'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
</head>
<body>
    <!-- navbar -->
    <?php $__env->startSection('navbar'); ?>
    <nav>
        <div class="navigation-bar">
            <div class="item-left">
                <div class="home-nav">
                    <a href="/dashboard/customer">Home</a>
                </div>

                <div class="kategori-nav">
                    <a href="/dashboard/customer/category">Kategori</a>
                </div>

                <div class="about-nav">
                    <a class="about-nav" href="">About</a>
                </div>
                <div class="FAQ-nav">
                    <a class="FAQ-nav" href="">FAQ</a>
                </div>
            </div>

            <div class="item-right">
                <!-- profile picture -->
                <a href="/profile/main">
                    <div class="profile">
                        <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $c->CustomerPicturePath)); ?>" alt="profile">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </a>

                <!-- change role -->
                <select name="role" id="role" onchange="location = this.value;" autofocus>
                    <option value="" selected>Customer</option>
                    <option value="/set_agent">Agent</option>
                </select>
            </div>
        </div>
    </nav>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $PakaianDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="content">
        <div class="kategori-type">
            <div class="kategori-title">
                <h1 style="text-align:center;">Detail</h1>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <img src="<?php echo e(asset('storage/' . $pd->PakaianGambar)); ?>" class="d-block w-100" alt="formal_acara">
                </div>
            </div>
        </div>

        <br>

        <div class="detailWrapper">
            <h1><?php echo e($pd->PakaianNama); ?></h1>
            <p>Rp. <?php echo e($pd->PakaianHarga); ?>/hari</p>

            <form action="/dashboard/customer/category/pakaian/buy" method="post">
                <?php echo csrf_field(); ?>
                <table class="table">
                    <tbody>
                        <tr>
                            <th scope="row">Code</th>
                            <td>: <?php echo e($pd->PakaianID); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Deskripsi</th>
                            <td>: <?php echo e($pd->PakaianDeskripsi); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Ukuran</th>
                            <td>: <?php echo e($pd->DeskripsiSize); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="date">Mulai Sewa</label></th>
                            <td> 
                                <input type="date" name="date" id="date" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="date2">Selesai Sewa</label></th>
                            <td> 
                                <input type="date" name="date2" id="date2" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Tipe Pembayaran</th>
                            <td>
                            <select name="payment_type">
                                <?php $__currentLoopData = $PaymentType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pt->PaymentMethodID); ?>"><?php echo e($pt->PaymentMethodName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Tipe Pengiriman</th>
                            <td>
                            <select name="delivery_services">
                                <?php $__currentLoopData = $DeliveryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ds->DeliveryServiceID); ?>"><?php echo e($ds->DeliveryServiceName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Tipe Laundry</th>
                            <td>
                            <select name="laundry_services">
                                <?php $__currentLoopData = $LaundryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ls->LaundryServiceID); ?>"><?php echo e($ls->LaundryServiceName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </td>
                        </tr>
                    </tbody>
                    <br>
                </table>
                <input type="hidden" name="PakaianID" value="<?php echo e($pd->PakaianID); ?>">
                <input type="hidden" name="PakaianHarga" value="<?php echo e($pd->PakaianHarga); ?>">
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success btn-block"> <b> SEWA </b></button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sewabajupedia\resources\views/customer-role\detail-pakaian.blade.php ENDPATH**/ ?>