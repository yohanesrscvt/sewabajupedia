<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h1>This is Customer Dashboard</h1><br>

    <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src='<?php echo e($c->CustomerPicturePath); ?>' alt="User Profile Image"><br>
        <p>Saldo: <?php echo e($c->CustomerSaldo); ?></p><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- change role -->
    <select name="role" id="role" onchange="location = this.value;" autofocus>
        <option value="">Customer</option>
        <option value="/set_agent">Agent</option>
    </select><br>

    <a href="">My Account</a><br>
    <a href="/logout">Logout</a>
</body>
</html><?php /**PATH D:\sewabajupedia\resources\views/customer-role\dashboard.blade.php ENDPATH**/ ?>