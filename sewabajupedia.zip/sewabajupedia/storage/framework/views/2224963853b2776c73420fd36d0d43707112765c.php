
<?php $__env->startSection('title','Konfirmasi'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/kategori_formal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
</head>
<body>
    <!-- navbar -->
    <?php $__env->startSection('navbar'); ?>
    <nav>
        <div class="navigation-bar">
            <div class="item-left">
                <div class="home-nav">
                    <a href="/dashboard/customer">Home</a>
                </div>

                <div class="kategori-nav">
                    <a href="/dashboard/customer/category">Kategori</a>
                </div>

                <div class="about-nav">
                    <a class="about-nav" href="">About</a>
                </div>
                <div class="FAQ-nav">
                    <a class="FAQ-nav" href="">FAQ</a>
                </div>
            </div>

            <div class="item-right">
                <!-- profile picture -->
                <a href="/profile/main">
                    <div class="profile">
                        <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/' . $c->CustomerPicturePath)); ?>" alt="profile">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </a>

                <!-- change role -->
                <select name="role" id="role" onchange="location = this.value;" autofocus>
                    <option value="" selected>Customer</option>
                    <option value="/set_agent">Agent</option>
                </select>
            </div>
        </div>
    </nav>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="kategori-type">
            <div class="kategori-title">
                <h1>Konfirmasi Pembayaran</h1>
            </div>
        </div>

        <?php $__currentLoopData = $PakaianDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="detailWrapper">
            <h1><?php echo e($pd->PakaianNama); ?></h1>
            <p>Rp. <?php echo e($pd->PakaianHarga); ?>/hari</p>

            <form action="/dashboard/customer/category/pakaian/buy/execute" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="AgentID" value="<?php echo e($pd->AgentID); ?>">
                <input type="hidden" name="PakaianHarga2" value="<?php echo e($pd->PakaianHarga); ?>">
                <table class="table">
                    <tbody>
                        <tr>
                            <th scope="row">Code</th>
                            <td>: <?php echo e($pd->PakaianID); ?></td>
                            <input type="hidden" name="PakaianID" value="<?php echo e($pd->PakaianID); ?>">
                        </tr>
                        <tr>
                            <th scope="row">Deskripsi</th>
                            <td>: <?php echo e($pd->PakaianDeskripsi); ?></td>
                        </tr>
                        <tr>
                            <th scope="row">Ukuran</th>
                            <td>: <?php echo e($pd->DeskripsiSize); ?> </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="hari" class="form-label">Sewa Untuk</label></th>
                            <td>: <?php echo e($RentDays); ?> hari </td>
                            <input type="hidden" name="LamaSewa" value="<?php echo e($RentDays); ?>">
                        </tr>
                        <tr>
                            <?php $__currentLoopData = $PaymentType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="PaymentMethodID" value="<?php echo e($pt->PaymentMethodID); ?>">
                                <th scope="row">Tipe Pembayaran</th>
                                <td>: <?php echo e($pt->PaymentMethodName); ?> </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                    <br>
                    <br>
                </table>
                <div class="detailPembayaran">
                    <h2>Detail Pembayaran</h2>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th scope="row">Biaya Per Hari</th>
                                <td>: Rp. <?php echo e($pd->PakaianHarga); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Biaya Antar</th>
                                <!-- delivery -->
                                <?php $__currentLoopData = $DeliveryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="DeliveryServiceID" value="<?php echo e($ds->DeliveryServiceID); ?>">
                                    <input type="hidden" name="DeliveryServicePrice" value="<?php echo e($ds->DeliveryServicePrice); ?>">
                                    <td>: Rp. <?php echo e($ds->DeliveryServicePrice); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th scope="row">Biaya Laundry</th>
                                <!-- laundry -->
                                <?php $__currentLoopData = $LaundryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="LaundryServiceID" value="<?php echo e($ls->LaundryServiceID); ?>">
                                    <input type="hidden" name="LaundryServicePrice" value="<?php echo e($ls->LaundryServicePrice); ?>">
                                    <td>: Rp. <?php echo e($ls->LaundryServicePrice); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th scope="row">Total Pembayaran</th>
                                <td id="total">: Rp. xxx.xxx</td>
                            </tr>

                        </tbody>
                    </table>
                </div>

                <!-- hidden input -->
                <input type="hidden" name="MulaiSewa" value="<?php echo e($StartRent); ?>">
                <input type="hidden" name="SelesaiSewa" value="<?php echo e($FinalRent); ?>">
                
                <?php $__currentLoopData = $CustomerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="CustomerSaldo" value="<?php echo e($c->CustomerSaldo); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success btn-block"> <b> Konfirmasi Sewa </b></button>
                </div>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- total -->
    <script>
        var DeliveryFee;
        var LaundryFee;
        var PakaianFee;
        <?php $__currentLoopData = $DeliveryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            DeliveryFee = <?php echo e($ds->DeliveryServicePrice); ?>;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $LaundryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            LaundryFee = <?php echo e($ls->LaundryServicePrice); ?>;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $PakaianDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            PakaianFee = <?php echo e($pd->PakaianHarga); ?>;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        var total = (<?php echo e($RentDays); ?> * PakaianFee) + LaundryFee + DeliveryFee;
        document.getElementById("total").innerHTML = ": " + total;
    </script>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sewabajupedia\resources\views/customer-role\konfirmasi.blade.php ENDPATH**/ ?>